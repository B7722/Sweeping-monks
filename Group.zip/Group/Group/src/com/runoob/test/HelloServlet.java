package com.runoob.test;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
    	String button = request.getParameter("button");
    	if(button.equals("Add")) {
	        String tetrahedron_1 = request.getParameter("tetrahedron_1");
	        String ball_p = request.getParameter("ball_p");
	        String cuboid_p = request.getParameter("cuboid_p");
	
	        String color_r = request.getParameter("color_r");
	        String color_g = request.getParameter("color_g");
	        String color_b = request.getParameter("color_b");
	        
	        String camera_p = request.getParameter("camera_p");
	        String camera_d = request.getParameter("camera_d");
	        String range = request.getParameter("range");
	
	        String txt = "Name:Camera,Parameters:"+camera_p+" "+camera_d+"\r\n";
	        if(!tetrahedron_1.equals("")) {
	            String tetrahedron_2 = request.getParameter("tetrahedron_2");
	            String tetrahedron_3 = request.getParameter("tetrahedron_3");
	            String tetrahedron_4 = request.getParameter("tetrahedron_4");
	            txt = txt+"Name:Tetrahedran,Parameters:"+tetrahedron_1+" "+tetrahedron_2+" "+tetrahedron_3+" "+tetrahedron_4+","+"Color:"+color_r+" "+color_g+" "+color_b+","+"Transparency:"+range+"\r\n";
	        }else if(!ball_p.equals("")) {
	        	String ball_r = request.getParameter("ball_r");
	        	txt = txt+"Name:Ball,Parameters:"+ball_p+" "+ball_r+","+"Color:"+color_r+" "+color_g+" "+color_b+","+"Transparency:"+range+"\r\n";
	        }else if(!cuboid_p.equals("")) {
	            String cuboid_x = request.getParameter("cuboid_x");
	            String cuboid_y = request.getParameter("cuboid_y");
	            String cuboid_z = request.getParameter("cuboid_z");
	        	txt = txt+"Name:Cuboid,Parameters:"+cuboid_p+" "+cuboid_x+" "+cuboid_y+" "+cuboid_z+","+"Color:"+color_r+" "+color_g+" "+color_b+","+"Transparency:"+range+"\r\n";
	        }
	        TxtFile.saveAsFileWriter(txt); 
	        request.getRequestDispatcher("2.html").forward(request, response);//ת�����ɹ�ҳ��
        } 
    	else if(button.equals("Clean")) {
    		DeleteTxt.delete();
	        request.getRequestDispatcher("2.html").forward(request, response);//ת�����ɹ�ҳ��
    	}
    	else if(button.equals("Save")){

	        request.getRequestDispatcher("2.html").forward(request, response);//ת�����ɹ�ҳ��
    	}
    }

}
